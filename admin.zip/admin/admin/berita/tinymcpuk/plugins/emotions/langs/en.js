// UK lang variables

tinyMCE.addToLang('emotions',{
title : 'Insert emotion',
desc : 'Emotions',
cool : 'Cool',
cry : 'Cry',
embarassed : 'Embarassed',
foot_in_mouth : 'Foot in mouth',
frown : 'Frown',
innocent : 'Innocent',
kiss : 'Kiss',
laughing : 'Laughing',
money_mouth : 'Money mouth',
sealed : 'Sealed',
smile : 'Smile',
surprised : 'Surprised',
tongue_out : 'Tongue out',
undecided : 'Undecided',
wink : 'Wink',
yell : 'Yell'
});
