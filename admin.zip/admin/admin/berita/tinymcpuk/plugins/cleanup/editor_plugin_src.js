/**
 * $Id: editor_plugin_src.js 18 2006-06-29 14:11:23Z spocke $
 *
 * Experimental plugin for new Cleanup routine, this logic will be moved into the core ones it's stable enougth.
 *
 * @author Moxiecode
 * @copyright Copyright � 2004-2006, Moxiecode Systems AB, All rights reserved.
 */

/* Dummy file since cleanup is now moved to core */
