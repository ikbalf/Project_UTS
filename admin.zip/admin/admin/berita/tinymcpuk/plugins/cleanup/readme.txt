Dummy plugin since cleanup is now moved into core.
