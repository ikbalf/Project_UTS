// UK lang variables

tinyMCE.addToLang('',{
lang_codehighlighting_desc : 'Code Highlighting',
lang_codehighlighting_title : 'Code Highlighting',
lang_codehighlighting_langaugepicker : 'Choose the language',
lang_codehighlighting_pagecode : 'Paste your code here',
lang_codehighlighting_button_desc: 'Insert code',
lang_codehighlighting_nogutter : 'No Gutter',
lang_codehighlighting_collapse : 'Collapes',
lang_codehighlighting_nocontrols : 'No Controls',
lang_codehighlighting_showcolumns : 'Show Columns'


});
