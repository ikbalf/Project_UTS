<td width="753" height="250" align="center" bgcolor="#FFFFFF">SELAMAT DATANG DI HALAMAN ADMINISTRATOR MLBB Pedia</td>
<br><center><p> <a href='https://mpl.com/' title='mpl.com' target='_blank'>MLBB Pedia</a></p></center>
